import cv2
import numpy as np
from time import sleep

min_width = 80  # Lebar minimum persegi panjang (bounding rectangle) mobil
min_height = 80  # Tinggi minimum persegi panjang (bounding rectangle) mobil

offset = 6  # Toleransi kesalahan piksel

line_position = 550  # Posisi garis hitung mobil

fps = 60  # Frame per detik (FPS) video

detected = []  # Daftar koordinat pusat mobil yang terdeteksi
cars = 0  # Jumlah mobil yang terdeteksi

# Fungsi untuk mendapatkan koordinat pusat dari persegi panjang
def get_center(x, y, w, h):
    x1 = int(w / 2)
    y1 = int(h / 2)
    cx = x + x1
    cy = y + y1
    return cx, cy

cap = cv2.VideoCapture('video.mp4')  # Membuka file video

# Membuat pengurang latar belakang menggunakan metode MOG (Mixture of Gaussians)
subtraction = cv2.bgsegm.createBackgroundSubtractorMOG()

while True:
    ret, frame1 = cap.read()  # Membaca frame video
    time = float(1 / fps)
    sleep(time)  # Mengatur waktu jeda antar frame
    gray = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)  # Mengubah gambar menjadi skala keabuan
    blur = cv2.GaussianBlur(gray, (3, 3), 5)  # Melakukan blur pada gambar
    img_sub = subtraction.apply(blur)  # Mengaplikasikan pengurang latar belakang
    dilate = cv2.dilate(img_sub, np.ones((5, 5)))  # Melakukan dilasi pada gambar hasil pengurangan latar belakang
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    dilated = cv2.morphologyEx(dilate, cv2.MORPH_CLOSE, kernel)  # Melakukan operasi morfologi (closing) pada gambar hasil dilasi
    dilated = cv2.morphologyEx(dilated, cv2.MORPH_CLOSE, kernel)
    contours, hierarchy = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Menggambar garis hitung mobil pada frame
    cv2.line(frame1, (25, line_position), (1200, line_position), (255, 127, 0), 3)

    # Melakukan deteksi mobil berdasarkan persegi panjang yang terdeteksi
    for (i, contour) in enumerate(contours):
        (x, y, w, h) = cv2.boundingRect(contour)
        validate_contour = (w >= min_width) and (h >= min_height)
        if not validate_contour:
            continue

        # Menggambar persegi panjang pada frame untuk setiap mobil yang terdeteksi
        cv2.rectangle(frame1, (x, y), (x + w, y + h), (0, 255, 0), 2)
        center = get_center(x, y, w, h)
        detected.append(center)
        cv2.circle(frame1, center, 4, (0, 0, 255), -1)

        # Memeriksa apakah mobil melewati garis hitung
        for (x, y) in detected:
            if y < (line_position + offset) and y > (line_position - offset):
                cars += 1
                # Menggambar garis hitung yang berhasil dilewati oleh mobil
                cv2.line(frame1, (25, line_position), (1200, line_position), (0, 127, 255), 3)
                detected.remove((x, y))
                print("Mobil terdeteksi: " + str(cars))

    # Menampilkan jumlah mobil yang terdeteksi pada frame
    cv2.putText(frame1, "JUMLAH MOBIL: " + str(cars), (450, 70), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 5)

    # Menampilkan frame asli dan frame dengan deteksi
    cv2.imshow("Video Asli", frame1)
    cv2.imshow("Deteksi", dilated)

    if cv2.waitKey(1) == 27:  # Tombol ESC untuk keluar
        break

cv2.destroyAllWindows()
cap.release()  # Melepas sumber video
